package com.accenture;

public class TType <T,Y>
{
	private T tId;
	private Y member2;
	public T gettId() {
		return tId;
	}
	public void settId(T tId) {
		this.tId = tId;
	}
	public Y getMember2() {
		return member2;
	}
	public void setMember2(Y member2) {
		this.member2 = member2;
	}
	
}
